<?
require_once(dirname(__FILE__)."/../../../wp-config.php");
nocache_headers();

$options = get_option('ym_status');

$ym_ids = $options['ids'];
if($_GET['id']) {
	$id = $_GET['id'] - 1;
	$ym_id = $ym_ids[$id];
} else {
	$ym_id = $ym_ids[0];
}
if($_GET['type']) {
	$filename_suffix = $_GET['type'];
} else {
	$filename_suffix = $options['button'];
}
$fileinfo = pathinfo($filename_suffix);
$extension = $fileinfo['extension'];
if($extension == 'jpg') {
	$extension = 'jpeg';
}

$yahoo_url = "http://opi.yahoo.com/online?u={$ym_id}&m=a&t=1";

if (ini_get('allow_url_fopen')) {
	error_reporting(0);
	$yahoo = file_get_contents($yahoo_url);
} elseif(function_exists('curl_init')) {
	$ch = curl_init($yahoo_url);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	$yahoo = curl_exec($ch);
	curl_close($ch);
}
$yahoo = trim($yahoo);
if(empty($yahoo)) {
	/* Maybe failed connection.*/
	$imgsrc = "./images/offline-" . $filename_suffix;
} elseif($yahoo == "01") {
	$imgsrc = "./images/online-" . $filename_suffix;
} elseif($yahoo == "00") {
	$imgsrc = "./images/offline-" . $filename_suffix;
} else {
	/* We don't know what happen but we'll use offline button anyway. */
	$imgsrc = "./images/offline-" . $filename_suffix;
}
header("Content-type: image/".$extension);
readfile($imgsrc);
?>
