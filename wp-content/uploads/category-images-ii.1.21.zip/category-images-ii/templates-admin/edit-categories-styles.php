<style type="text/css" media="screen">
	table.form-table .form-field input {
		width: auto;
	}
</style>