<?php if (!defined ('ABSPATH')) die ('No direct access allowed'); ?>
<ul class="category_images_ii">
<?php foreach( $terms AS & $term ) { ?>
	<li class="category_image"><?php if ( $link_images ) : ?><a href="<?php echo esc_attr( get_category_link( $term[ 'id' ] ) ); ?>"><?php endif; ?><img src="<?php echo $term[ 'thumbnail' ]; ?>" alt="<?php echo $term[ 'name' ]; ?>" /><?php if ( $link_images ) : ?></a><?php endif; ?>
	<p><?php category_description( $category[ 'id' ] ); ?></p></li>
<?php } ?>
</ul>